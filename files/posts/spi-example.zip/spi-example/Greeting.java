public interface Greeting {
    public String hello();
}
