# How to run the program

```
$ javac *.java
$ java Main
```
