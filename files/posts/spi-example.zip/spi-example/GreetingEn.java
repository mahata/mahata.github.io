public class GreetingEn implements Greeting {
    public String hello() {
        return "Hello.";
    }
}
