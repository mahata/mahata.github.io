public class GreetingJa implements Greeting {
    public String hello() {
        return "こんにちは";
    }
}
