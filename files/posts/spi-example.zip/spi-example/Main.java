import java.util.ServiceLoader;

public class Main {
    public static void main(String[] args) {
        ServiceLoader<Greeting> loader = ServiceLoader.load(Greeting.class);

        for (Greeting greeting: loader) {
            System.out.println(greeting.getClass());
            System.out.println(greeting.hello());
        }
    }
}
